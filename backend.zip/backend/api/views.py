from rest_framework import viewsets, status
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate, get_user_model
from django.db.models import Q, Count
from django.utils import timezone
import openpyxl
from openpyxl.styles import Font, Alignment
from django.http import HttpResponse
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from io import BytesIO

from .models import FormLink, FormSubmission, Guardian, Orphan, Attachment
from .serializers import (
    UserSerializer, UserCreateSerializer, FormLinkSerializer,
    FormSubmissionSerializer, OrphanSerializer,
    OrphanDetailSerializer, AttachmentSerializer, GuardianSerializer
)
from .permissions import IsAdminUser

User = get_user_model()


@api_view(['POST'])
@permission_classes([AllowAny])
def login_view(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    if not username or not password:
        return Response({'error': 'Please provide both username and password'}, 
                       status=status.HTTP_400_BAD_REQUEST)
    
    user = authenticate(username=username, password=password)
    
    if user:
        refresh = RefreshToken.for_user(user)
        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'user': UserSerializer(user).data
        })
    
    return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)


@api_view(['POST'])
@permission_classes([IsAdminUser])
def register_user(request):
    serializer = UserCreateSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def current_user(request):
    return Response(UserSerializer(request.user).data)


class FormLinkViewSet(viewsets.ModelViewSet):
    queryset = FormLink.objects.all()
    serializer_class = FormLinkSerializer
    permission_classes = [IsAuthenticated]
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    @action(detail=True, methods=['get'], permission_classes=[AllowAny])
    def check(self, request, pk=None):
        try:
            form_link = FormLink.objects.get(unique_id=pk, is_active=True)
            if form_link.is_expired():
                return Response({'error': 'This form link has expired'}, 
                              status=status.HTTP_400_BAD_REQUEST)
            return Response({'valid': True, 'title': form_link.title})
        except FormLink.DoesNotExist:
            return Response({'error': 'Invalid or inactive form link'}, 
                          status=status.HTTP_404_NOT_FOUND)

    def get_object(self):
        # Override to support lookup by unique_id
        if 'pk' in self.kwargs:
            pk = self.kwargs['pk']
            # Try to get by unique_id first
            try:
                return FormLink.objects.get(unique_id=pk)
            except FormLink.DoesNotExist:
                # Fall back to regular id lookup
                return FormLink.objects.get(pk=pk)
        return super().get_object()


class FormSubmissionViewSet(viewsets.ModelViewSet):
    queryset = FormSubmission.objects.all()
    serializer_class = FormSubmissionSerializer
    permission_classes = [IsAuthenticated]
    
    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'save_draft', 'submit']:
            return [AllowAny()]
        return [IsAuthenticated()]
    
    @action(detail=False, methods=['post'], permission_classes=[AllowAny])
    def save_draft(self, request):
        form_link_id = request.data.get('form_link_id')
        session_key = request.data.get('session_key')
        progress_data = request.data.get('progress_data', {})
        
        try:
            form_link = FormLink.objects.get(unique_id=form_link_id, is_active=True)
            
            submission, created = FormSubmission.objects.get_or_create(
                form_link=form_link,
                session_key=session_key,
                defaults={'status': 'draft', 'progress_data': progress_data}
            )
            
            if not created:
                submission.progress_data = progress_data
                submission.save()
            
            return Response({'message': 'Draft saved successfully', 'id': submission.id})
        except FormLink.DoesNotExist:
            return Response({'error': 'Invalid form link'}, status=status.HTTP_404_NOT_FOUND)
    
    @action(detail=False, methods=['post'], permission_classes=[AllowAny])
    def submit(self, request):
        from django.db import IntegrityError
        
        form_link_id = request.data.get('form_link_id')
        session_key = request.data.get('session_key')
        guardian_data = request.data.get('guardian_data')
        orphans_data = request.data.get('orphans_data', [])
        
        if not guardian_data:
            return Response({'error': 'Guardian data is required'}, 
                          status=status.HTTP_400_BAD_REQUEST)
        
        if not orphans_data or len(orphans_data) == 0:
            return Response({'error': 'At least one orphan is required'}, 
                          status=status.HTTP_400_BAD_REQUEST)
        
        martyr_id = guardian_data.get('martyr_id_number')
        if martyr_id and Guardian.objects.filter(martyr_id_number=martyr_id).exists():
            return Response({'error': 'رقم هوية الشهيد موجود مسبقاً في النظام'}, 
                          status=status.HTTP_400_BAD_REQUEST)
        
        orphan_ids = [orphan.get('id_number') for orphan in orphans_data if orphan.get('id_number')]
        if len(orphan_ids) != len(set(orphan_ids)):
            return Response({'error': 'يوجد أرقام هوية مكررة للأيتام في النموذج'}, 
                          status=status.HTTP_400_BAD_REQUEST)
        
        for orphan_id in orphan_ids:
            if Orphan.objects.filter(id_number=orphan_id).exists():
                return Response({'error': f'رقم الهوية {orphan_id} موجود مسبقاً في النظام'}, 
                              status=status.HTTP_400_BAD_REQUEST)
        
        try:
            form_link = FormLink.objects.get(unique_id=form_link_id, is_active=True)
            
            if form_link.is_expired():
                return Response({'error': 'This form link has expired'}, 
                              status=status.HTTP_400_BAD_REQUEST)
            
            submission = FormSubmission.objects.filter(
                form_link=form_link,
                session_key=session_key
            ).first()
            
            if not submission:
                submission = FormSubmission.objects.create(
                    form_link=form_link,
                    session_key=session_key,
                    status='draft'
                )
            else:
                if hasattr(submission, 'guardian_data') and submission.guardian_data:
                    submission.guardian_data.orphans.all().delete()
                    submission.guardian_data.delete()
            
            guardian = Guardian.objects.create(
                submission=submission,
                **guardian_data
            )
            
            for orphan_data in orphans_data:
                Orphan.objects.create(
                    guardian=guardian,
                    **orphan_data
                )
            
            submission.status = 'completed'
            submission.submitted_at = timezone.now()
            submission.save()
            
            return Response({
                'message': 'Form submitted successfully',
                'submission_id': submission.id
            }, status=status.HTTP_201_CREATED)
            
        except FormLink.DoesNotExist:
            return Response({'error': 'Invalid form link'}, status=status.HTTP_404_NOT_FOUND)
        except IntegrityError as e:
            if 'martyr_id_number' in str(e):
                return Response({'error': 'رقم هوية الشهيد موجود مسبقاً في النظام'}, 
                              status=status.HTTP_400_BAD_REQUEST)
            elif 'id_number' in str(e):
                return Response({'error': 'رقم الهوية موجود مسبقاً في النظام'}, 
                              status=status.HTTP_400_BAD_REQUEST)
            return Response({'error': f'خطأ في البيانات المدخلة: {str(e)}'}, 
                          status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            import traceback
            return Response({
                'error': str(e),
                'details': traceback.format_exc()
            }, status=status.HTTP_400_BAD_REQUEST)


class OrphanViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Orphan.objects.all().select_related('guardian__submission').prefetch_related('attachments')
    permission_classes = [IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return OrphanDetailSerializer
        return OrphanSerializer
    
    def get_queryset(self):
        queryset = super().get_queryset()
        
        search = self.request.query_params.get('search', None)
        governorate = self.request.query_params.get('governorate', None)
        gender = self.request.query_params.get('gender', None)
        education_level = self.request.query_params.get('education_level', None)
        
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) |
                Q(id_number__icontains=search) |
                Q(guardian__guardian_name__icontains=search)
            )
        
        if governorate:
            queryset = queryset.filter(governorate=governorate)
        
        if gender:
            queryset = queryset.filter(gender=gender)
        
        if education_level:
            queryset = queryset.filter(education_level=education_level)
        
        return queryset
    
    @action(detail=True, methods=['delete'], permission_classes=[IsAdminUser])
    def delete_orphan(self, request, pk=None):
        orphan = self.get_object()
        orphan.delete()
        return Response({'message': 'Orphan deleted successfully'}, 
                       status=status.HTTP_204_NO_CONTENT)


class GuardianViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Guardian.objects.all().prefetch_related('orphans__attachments').select_related('submission')
    serializer_class = GuardianSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = super().get_queryset()
        
        search = self.request.query_params.get('search', None)
        governorate = self.request.query_params.get('governorate', None)
        
        if search:
            queryset = queryset.filter(
                Q(guardian_name__icontains=search) |
                Q(guardian_id_number__icontains=search) |
                Q(martyr_name__icontains=search) |
                Q(phone_number_1__icontains=search)
            )
        
        if governorate:
            queryset = queryset.filter(governorate=governorate)
        
        return queryset


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def statistics_view(request):
    total_orphans = Orphan.objects.count()
    total_submissions = FormSubmission.objects.filter(status='completed').count()
    
    orphans_by_governorate = Orphan.objects.values('governorate').annotate(
        count=Count('id')
    ).order_by('-count')
    
    orphans_by_gender = Orphan.objects.values('gender').annotate(
        count=Count('id')
    )
    
    orphans_by_education = Orphan.objects.values('education_level').annotate(
        count=Count('id')
    ).order_by('-count')
    
    orphans_by_health = Orphan.objects.values('health_status').annotate(
        count=Count('id')
    )
    
    guardians_by_relation = Guardian.objects.values('guardian_relation').annotate(
        count=Count('id')
    )
    
    recent_submissions = FormSubmission.objects.filter(
        status='completed'
    ).order_by('-submitted_at')[:10]
    
    return Response({
        'total_orphans': total_orphans,
        'total_submissions': total_submissions,
        'orphans_by_governorate': list(orphans_by_governorate),
        'orphans_by_gender': list(orphans_by_gender),
        'orphans_by_education': list(orphans_by_education),
        'orphans_by_health': list(orphans_by_health),
        'guardians_by_relation': list(guardians_by_relation),
        'recent_submissions': FormSubmissionSerializer(recent_submissions, many=True).data
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def export_excel(request):
    orphans = Orphan.objects.all().select_related('guardian')
    
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = 'Orphans Data'
    
    headers = [
        'Serial Number', 'Orphan Name', 'ID Number', 'Gender', 'Birth Date',
        'Education Level', 'Health Status', 'Governorate', 'Neighborhood',
        'Guardian Name', 'Guardian ID', 'Guardian Phone', 'Martyr Name',
        'Martyrdom Date', 'Mother Name'
    ]
    
    for col_num, header in enumerate(headers, 1):
        cell = sheet.cell(row=1, column=col_num)
        cell.value = header
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal='center')
    
    for row_num, orphan in enumerate(orphans, 2):
        sheet.cell(row=row_num, column=1).value = orphan.guardian.serial_number
        sheet.cell(row=row_num, column=2).value = orphan.name
        sheet.cell(row=row_num, column=3).value = orphan.id_number
        sheet.cell(row=row_num, column=4).value = orphan.get_gender_display()
        sheet.cell(row=row_num, column=5).value = str(orphan.birth_date)
        sheet.cell(row=row_num, column=6).value = orphan.get_education_level_display()
        sheet.cell(row=row_num, column=7).value = orphan.get_health_status_display()
        sheet.cell(row=row_num, column=8).value = orphan.governorate
        sheet.cell(row=row_num, column=9).value = orphan.neighborhood
        sheet.cell(row=row_num, column=10).value = orphan.guardian.guardian_name
        sheet.cell(row=row_num, column=11).value = orphan.guardian.guardian_id_number
        sheet.cell(row=row_num, column=12).value = orphan.guardian.phone_number_1
        sheet.cell(row=row_num, column=13).value = orphan.guardian.martyr_name
        sheet.cell(row=row_num, column=14).value = str(orphan.guardian.martyrdom_date)
        sheet.cell(row=row_num, column=15).value = orphan.guardian.mother_name
    
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename=orphans_data_{timezone.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
    
    workbook.save(response)
    return response


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def export_pdf(request, orphan_id):
    try:
        orphan = Orphan.objects.select_related('guardian').get(id=orphan_id)
    except Orphan.DoesNotExist:
        return Response({'error': 'Orphan not found'}, status=status.HTTP_404_NOT_FOUND)
    
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = []
    styles = getSampleStyleSheet()
    
    title = Paragraph(f"<b>Orphan Record: {orphan.name}</b>", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 20))
    
    data = [
        ['Field', 'Value'],
        ['Name', orphan.name],
        ['ID Number', orphan.id_number],
        ['Gender', orphan.get_gender_display()],
        ['Birth Date', str(orphan.birth_date)],
        ['Education Level', orphan.get_education_level_display()],
        ['Health Status', orphan.get_health_status_display()],
        ['Governorate', orphan.governorate],
        ['Neighborhood', orphan.neighborhood],
        ['Guardian Name', orphan.guardian.guardian_name],
        ['Guardian ID', orphan.guardian.guardian_id_number],
        ['Guardian Phone', orphan.guardian.phone_number_1],
        ['Martyr Name', orphan.guardian.martyr_name],
        ['Martyrdom Date', str(orphan.guardian.martyrdom_date)],
        ['Mother Name', orphan.guardian.mother_name],
    ]
    
    table = Table(data, colWidths=[200, 300])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(table)
    doc.build(elements)
    
    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename=orphan_{orphan.id}_{timezone.now().strftime("%Y%m%d")}.pdf'
    
    return response


@api_view(['POST'])
@permission_classes([AllowAny])
def upload_attachment(request):
    submission_id = request.data.get('submission_id')
    orphan_id = request.data.get('orphan_id')
    attachment_type = request.data.get('attachment_type')
    file = request.FILES.get('file')
    
    if not submission_id or not attachment_type or not file:
        return Response({'error': 'Missing required fields'}, 
                       status=status.HTTP_400_BAD_REQUEST)
    
    try:
        submission = FormSubmission.objects.get(id=submission_id)
        
        attachment = Attachment.objects.create(
            submission=submission,
            orphan_id=orphan_id if orphan_id else None,
            attachment_type=attachment_type,
            file=file
        )
        
        return Response(AttachmentSerializer(attachment).data, 
                       status=status.HTTP_201_CREATED)
    except FormSubmission.DoesNotExist:
        return Response({'error': 'Submission not found'}, 
                       status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
