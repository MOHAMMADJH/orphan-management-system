from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinLengthValidator, MaxLengthValidator, RegexValidator
from django.utils import timezone
import uuid
from .validators import validate_phone_number

class User(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('user', 'User'),
    ]
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='user')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'users'

    def __str__(self):
        return f"{self.username} ({self.role})"


class FormLink(models.Model):
    unique_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='form_links')
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    title = models.CharField(max_length=255, blank=True)
    
    class Meta:
        db_table = 'form_links'
        ordering = ['-created_at']

    def __str__(self):
        return f"Form Link: {self.unique_id}"

    def is_expired(self):
        if self.expires_at:
            return timezone.now() > self.expires_at
        return False


class FormSubmission(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('completed', 'Completed'),
    ]
    
    form_link = models.ForeignKey(FormLink, on_delete=models.CASCADE, related_name='submissions')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    progress_data = models.JSONField(default=dict, blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    session_key = models.CharField(max_length=255, unique=True)
    
    class Meta:
        db_table = 'form_submissions'
        ordering = ['-created_at']

    def __str__(self):
        return f"Submission: {self.session_key} - {self.status}"


class Guardian(models.Model):
    SPOUSE_STATUS_CHOICES = [
        ('martyr', 'Martyr'),
        ('deceased', 'Deceased'),
    ]
    
    WORK_NATURE_CHOICES = [
        ('government', 'Government Employee'),
        ('unrwa', 'UNRWA Employee'),
        ('private', 'Private Sector'),
        ('unemployed', 'Unemployed'),
    ]
    
    REFUGEE_STATUS_CHOICES = [
        ('citizen', 'Citizen'),
        ('refugee', 'Refugee'),
    ]
    
    WIFE_STATUS_CHOICES = [
        ('alive', 'Alive'),
        ('martyr', 'Martyr'),
    ]
    
    RESIDENCE_NATURE_CHOICES = [
        ('displaced', 'Displaced'),
        ('original', 'Original Home'),
    ]
    
    HOME_STATUS_CHOICES = [
        ('total_destruction', 'Total Destruction'),
        ('severe_partial', 'Severe Partial Damage'),
    ]
    
    LOCATION_CHOICES = [
        ('north', 'North of Valley'),
        ('south', 'South of Valley'),
    ]
    
    GUARDIAN_RELATION_CHOICES = [
        ('mother', 'Mother'),
        ('grandfather', 'Grandfather'),
        ('uncle_maternal', 'Maternal Uncle'),
        ('uncle_paternal', 'Paternal Uncle'),
        ('other', 'Other'),
    ]
    
    submission = models.OneToOneField(FormSubmission, on_delete=models.CASCADE, related_name='guardian_data')
    serial_number = models.CharField(max_length=50)
    spouse_status = models.CharField(max_length=20, choices=SPOUSE_STATUS_CHOICES)
    martyr_name = models.CharField(max_length=255)
    martyr_id_number = models.CharField(
        max_length=9,
        unique=True,
        validators=[
            MinLengthValidator(9),
            MaxLengthValidator(9),
            RegexValidator(regex=r'^\d{9}$', message='ID must be exactly 9 digits')
        ]
    )
    orphans_count = models.IntegerField()
    martyrdom_date = models.DateField()
    father_work_nature = models.CharField(max_length=20, choices=WORK_NATURE_CHOICES)
    refugee_status = models.CharField(max_length=20, choices=REFUGEE_STATUS_CHOICES)
    wife_status = models.CharField(max_length=20, choices=WIFE_STATUS_CHOICES)
    mother_name = models.CharField(max_length=255)
    mother_id_number = models.CharField(
        max_length=9,
        validators=[
            MinLengthValidator(9),
            MaxLengthValidator(9),
            RegexValidator(regex=r'^\d{9}$', message='ID must be exactly 9 digits')
        ]
    )
    mother_loss_date = models.DateField(null=True, blank=True)
    mother_work_nature = models.CharField(max_length=20, choices=WORK_NATURE_CHOICES)
    governorate = models.CharField(max_length=100, default='Gaza')
    original_address = models.TextField()
    current_residence_nature = models.CharField(max_length=20, choices=RESIDENCE_NATURE_CHOICES)
    current_residence_address = models.TextField()
    home_status = models.CharField(max_length=30, choices=HOME_STATUS_CHOICES)
    current_location = models.CharField(max_length=20, choices=LOCATION_CHOICES)
    guardian_name = models.CharField(max_length=255)
    guardian_id_number = models.CharField(
        max_length=9,
        validators=[
            MinLengthValidator(9),
            MaxLengthValidator(9),
            RegexValidator(regex=r'^\d{9}$', message='ID must be exactly 9 digits')
        ]
    )
    guardian_relation = models.CharField(max_length=30, choices=GUARDIAN_RELATION_CHOICES)
    phone_number_1 = models.CharField(max_length=20, validators=[validate_phone_number])
    phone_number_2 = models.CharField(max_length=20, blank=True, validators=[validate_phone_number])
    phone_number_3 = models.CharField(max_length=20, blank=True, validators=[validate_phone_number])
    phone_number_4 = models.CharField(max_length=20, blank=True, validators=[validate_phone_number])
    bank_account_number = models.CharField(max_length=50)
    account_holder_name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'guardians'

    def __str__(self):
        return f"{self.guardian_name} - {self.serial_number}"


class Orphan(models.Model):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
    ]
    
    EDUCATION_LEVEL_CHOICES = [
        ('kindergarten', 'Kindergarten'),
        ('elementary', 'Elementary'),
        ('preparatory', 'Preparatory'),
        ('secondary', 'Secondary'),
        ('university', 'University'),
    ]
    
    HEALTH_STATUS_CHOICES = [
        ('good', 'Good'),
        ('sick', 'Sick'),
    ]
    
    GUARDIAN_APPROVAL_CHOICES = [
        ('mother', 'Mother'),
        ('grandfather', 'Grandfather'),
        ('uncle', 'Uncle'),
        ('other', 'Other'),
    ]
    
    guardian = models.ForeignKey(Guardian, on_delete=models.CASCADE, related_name='orphans')
    name = models.CharField(max_length=255)
    id_number = models.CharField(
        max_length=9,
        unique=True,
        validators=[
            MinLengthValidator(9),
            MaxLengthValidator(9),
            RegexValidator(regex=r'^\d{9}$', message='ID must be exactly 9 digits')
        ]
    )
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    birth_date = models.DateField()
    education_level = models.CharField(max_length=20, choices=EDUCATION_LEVEL_CHOICES)
    health_status = models.CharField(max_length=20, choices=HEALTH_STATUS_CHOICES)
    disability_status = models.TextField(blank=True)
    governorate = models.CharField(max_length=100)
    neighborhood = models.CharField(max_length=100)
    guardian_approval_from = models.CharField(max_length=30, choices=GUARDIAN_APPROVAL_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'orphans'

    def __str__(self):
        return f"{self.name} - {self.id_number}"


class Attachment(models.Model):
    ATTACHMENT_TYPE_CHOICES = [
        ('orphan_photo', 'Orphan Photo'),
        ('death_certificate', 'Death Certificate'),
        ('martyr_id', 'Martyr ID'),
        ('wife_id', 'Wife ID'),
        ('birth_certificate', 'Birth Certificate'),
        ('guardianship_document', 'Guardianship Document'),
        ('guardian_id', 'Guardian ID'),
    ]
    
    submission = models.ForeignKey(FormSubmission, on_delete=models.CASCADE, related_name='attachments')
    orphan = models.ForeignKey(Orphan, on_delete=models.CASCADE, related_name='attachments', null=True, blank=True)
    attachment_type = models.CharField(max_length=30, choices=ATTACHMENT_TYPE_CHOICES)
    file = models.FileField(upload_to='attachments/%Y/%m/%d/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'attachments'

    def __str__(self):
        return f"{self.attachment_type} - {self.file.name}"
