from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, FormLink, FormSubmission, Guardian, Orphan, Attachment


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ['username', 'email', 'role', 'is_staff', 'created_at']
    list_filter = ['role', 'is_staff', 'is_active']
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Additional Info', {'fields': ('role', 'created_at', 'updated_at')}),
    )
    readonly_fields = ['created_at', 'updated_at']


@admin.register(FormLink)
class FormLinkAdmin(admin.ModelAdmin):
    list_display = ['title', 'unique_id', 'created_by', 'is_active', 'created_at', 'expires_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['title', 'unique_id']
    readonly_fields = ['unique_id', 'created_at']


@admin.register(FormSubmission)
class FormSubmissionAdmin(admin.ModelAdmin):
    list_display = ['id', 'form_link', 'status', 'session_key', 'submitted_at', 'created_at']
    list_filter = ['status', 'created_at', 'submitted_at']
    search_fields = ['session_key']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Guardian)
class GuardianAdmin(admin.ModelAdmin):
    list_display = ['serial_number', 'guardian_name', 'martyr_name', 'orphans_count', 'created_at']
    search_fields = ['serial_number', 'guardian_name', 'martyr_name', 'guardian_id_number']
    list_filter = ['governorate', 'spouse_status', 'created_at']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Orphan)
class OrphanAdmin(admin.ModelAdmin):
    list_display = ['name', 'id_number', 'gender', 'birth_date', 'education_level', 'governorate']
    search_fields = ['name', 'id_number']
    list_filter = ['gender', 'education_level', 'health_status', 'governorate', 'created_at']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Attachment)
class AttachmentAdmin(admin.ModelAdmin):
    list_display = ['id', 'attachment_type', 'submission', 'orphan', 'uploaded_at']
    list_filter = ['attachment_type', 'uploaded_at']
    readonly_fields = ['uploaded_at']
