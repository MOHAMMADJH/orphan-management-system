from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView
from . import views

router = DefaultRouter()
router.register(r'form-links', views.FormLinkViewSet, basename='formlink')
router.register(r'form-submissions', views.FormSubmissionViewSet, basename='submission')
router.register(r'orphans', views.OrphanViewSet, basename='orphan')
router.register(r'guardians', views.GuardianViewSet, basename='guardian')

urlpatterns = [
    path('', include(router.urls)),
    path('auth/login/', views.login_view, name='login'),
    path('auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/register/', views.register_user, name='register'),
    path('auth/me/', views.current_user, name='current_user'),
    path('statistics/', views.statistics_view, name='statistics'),
    path('export/excel/', views.export_excel, name='export_excel'),
    path('export/pdf/<int:orphan_id>/', views.export_pdf, name='export_pdf'),
    path('attachments/upload/', views.upload_attachment, name='upload_attachment'),
]

