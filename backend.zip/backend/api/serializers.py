from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.utils import timezone
from .models import FormLink, FormSubmission, Guardian, Orphan, Attachment

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'role', 'created_at']
        read_only_fields = ['id', 'created_at']


class UserCreateSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'first_name', 'last_name', 'role']
    
    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user


class FormLinkSerializer(serializers.ModelSerializer):
    created_by_username = serializers.CharField(source='created_by.username', read_only=True)
    submissions_count = serializers.SerializerMethodField()
    
    class Meta:
        model = FormLink
        fields = ['id', 'unique_id', 'title', 'created_by', 'created_by_username', 
                  'created_at', 'expires_at', 'is_active', 'submissions_count']
        read_only_fields = ['id', 'unique_id', 'created_at', 'created_by']
    
    def get_submissions_count(self, obj):
        return obj.submissions.filter(status='completed').count()


class AttachmentSerializer(serializers.ModelSerializer):
    file = serializers.SerializerMethodField()
    
    class Meta:
        model = Attachment
        fields = ['id', 'attachment_type', 'file', 'uploaded_at']
        read_only_fields = ['id', 'uploaded_at']
    
    def get_file(self, obj):
        request = self.context.get('request')
        if obj.file:
            if request is not None:
                return request.build_absolute_uri(obj.file.url)
            return obj.file.url
        return None


class OrphanSerializer(serializers.ModelSerializer):
    attachments = AttachmentSerializer(many=True, read_only=True)
    guardian = serializers.SerializerMethodField()
    submission = serializers.SerializerMethodField()
    
    class Meta:
        model = Orphan
        fields = ['id', 'name', 'id_number', 'gender', 'birth_date', 'education_level',
                  'health_status', 'disability_status', 'governorate', 'neighborhood',
                  'guardian_approval_from', 'attachments', 'guardian', 'submission', 
                  'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']
    
    def get_guardian(self, obj):
        guardian = obj.guardian
        return {
            'serial_number': guardian.serial_number,
            'guardian_name': guardian.guardian_name,
            'guardian_id_number': guardian.guardian_id_number,
            'guardian_relation': guardian.guardian_relation,
            'phone_number_1': guardian.phone_number_1,
            'phone_number_2': guardian.phone_number_2,
            'phone_number_3': guardian.phone_number_3,
            'phone_number_4': guardian.phone_number_4,
            'spouse_status': guardian.spouse_status,
            'martyr_name': guardian.martyr_name,
            'martyr_id_number': guardian.martyr_id_number,
            'martyrdom_date': guardian.martyrdom_date,
            'father_work_nature': guardian.father_work_nature,
            'orphans_count': guardian.orphans_count,
            'refugee_status': guardian.refugee_status,
            'wife_status': guardian.wife_status,
            'mother_name': guardian.mother_name,
            'mother_id_number': guardian.mother_id_number,
            'mother_loss_date': guardian.mother_loss_date,
            'mother_work_nature': guardian.mother_work_nature,
            'governorate': guardian.governorate,
            'original_address': guardian.original_address,
            'current_residence_nature': guardian.current_residence_nature,
            'current_residence_address': guardian.current_residence_address,
            'home_status': guardian.home_status,
            'current_location': guardian.current_location,
            'bank_account_number': guardian.bank_account_number,
            'account_holder_name': guardian.account_holder_name
        }
    
    def get_submission(self, obj):
        return {
            'id': obj.guardian.submission.id,
            'submitted_at': obj.guardian.submission.submitted_at
        }


class OrphanSimpleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Orphan
        fields = ['id', 'name', 'id_number', 'gender', 'birth_date', 'education_level',
                  'health_status', 'disability_status', 'governorate', 'neighborhood',
                  'guardian_approval_from', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class GuardianSerializer(serializers.ModelSerializer):
    orphans = OrphanSimpleSerializer(many=True, read_only=True)
    
    class Meta:
        model = Guardian
        fields = ['id', 'serial_number', 'spouse_status', 'martyr_name', 'martyr_id_number',
                  'orphans_count', 'martyrdom_date', 'father_work_nature', 'refugee_status',
                  'wife_status', 'mother_name', 'mother_id_number', 'mother_loss_date',
                  'mother_work_nature', 'governorate', 'original_address',
                  'current_residence_nature', 'current_residence_address', 'home_status',
                  'current_location', 'guardian_name', 'guardian_id_number', 'guardian_relation',
                  'phone_number_1', 'phone_number_2', 'phone_number_3', 'phone_number_4',
                  'bank_account_number', 'account_holder_name', 'orphans', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class FormSubmissionSerializer(serializers.ModelSerializer):
    guardian_data = GuardianSerializer(read_only=True)
    attachments = AttachmentSerializer(many=True, read_only=True)
    
    class Meta:
        model = FormSubmission
        fields = ['id', 'form_link', 'status', 'progress_data', 'submitted_at',
                  'session_key', 'guardian_data', 'attachments', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class FormSubmissionCreateSerializer(serializers.Serializer):
    session_key = serializers.CharField(required=True)
    guardian_data = serializers.DictField()
    orphans_data = serializers.ListField(child=serializers.DictField())
    attachments = serializers.ListField(child=serializers.FileField(), required=False)
    
    def validate_guardian_data(self, value):
        martyr_id = value.get('martyr_id_number')
        if martyr_id and Guardian.objects.filter(martyr_id_number=martyr_id).exists():
            raise serializers.ValidationError({
                'martyr_id_number': 'رقم هوية الشهيد موجود مسبقاً في النظام'
            })
        return value
    
    def validate_orphans_data(self, value):
        orphan_ids = [orphan.get('id_number') for orphan in value if orphan.get('id_number')]
        
        if len(orphan_ids) != len(set(orphan_ids)):
            raise serializers.ValidationError('يوجد أرقام هوية مكررة للأيتام في النموذج')
        
        for orphan_id in orphan_ids:
            if Orphan.objects.filter(id_number=orphan_id).exists():
                raise serializers.ValidationError({
                    'id_number': f'رقم الهوية {orphan_id} موجود مسبقاً في النظام'
                })
        
        return value
    
    def create(self, validated_data):
        form_link = validated_data.pop('form_link')
        session_key = validated_data.pop('session_key')
        guardian_data = validated_data.pop('guardian_data')
        orphans_data = validated_data.pop('orphans_data')
        validated_data.pop('attachments', [])
        
        submission = FormSubmission.objects.create(
            form_link=form_link,
            session_key=session_key,
            status='completed',
            submitted_at=timezone.now()
        )
        
        guardian = Guardian.objects.create(
            submission=submission,
            **guardian_data
        )
        
        for orphan_data in orphans_data:
            Orphan.objects.create(
                guardian=guardian,
                **orphan_data
            )
        
        return submission


class OrphanDetailSerializer(serializers.ModelSerializer):
    guardian_name = serializers.CharField(source='guardian.guardian_name', read_only=True)
    guardian_phone = serializers.CharField(source='guardian.phone_number_1', read_only=True)
    martyr_name = serializers.CharField(source='guardian.martyr_name', read_only=True)
    
    class Meta:
        model = Orphan
        fields = ['id', 'name', 'id_number', 'gender', 'birth_date', 'education_level',
                  'health_status', 'disability_status', 'governorate', 'neighborhood',
                  'guardian_name', 'guardian_phone', 'martyr_name',
                  'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

