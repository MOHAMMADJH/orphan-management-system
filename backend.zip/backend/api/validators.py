from django.core.exceptions import ValidationError
import re


def validate_palestinian_id(value):
    if not value:
        raise ValidationError('ID number is required')
    
    value_str = str(value).strip()
    
    if not re.match(r'^\d{9}$', value_str):
        raise ValidationError('Palestinian ID must be exactly 9 digits')
    
    return value


def validate_phone_number(value):
    if not value:
        return value
    
    value_str = str(value).strip()
    
    if not re.match(r'^(\+970|970|0)?[1-9]\d{8}$', value_str):
        raise ValidationError('Invalid Palestinian phone number format')
    
    return value


def validate_required_attachments(submission):
    required_attachments = [
        'death_certificate',
        'martyr_id',
        'wife_id',
        'guardianship_document',
        'guardian_id',
    ]
    
    existing_attachments = submission.attachments.values_list('attachment_type', flat=True)
    missing = set(required_attachments) - set(existing_attachments)
    
    if missing:
        raise ValidationError(f'Missing required attachments: {", ".join(missing)}')
    
    guardian = submission.guardian_data
    if guardian:
        orphans_count = guardian.orphans.count()
        
        orphan_photos = submission.attachments.filter(
            attachment_type='orphan_photo'
        ).count()
        
        birth_certificates = submission.attachments.filter(
            attachment_type='birth_certificate'
        ).count()
        
        if orphan_photos < orphans_count:
            raise ValidationError(f'Missing orphan photos: {orphans_count - orphan_photos} required')
        
        if birth_certificates < orphans_count:
            raise ValidationError(f'Missing birth certificates: {orphans_count - birth_certificates} required')
    
    return True

