# Orphan Management System - Backend

Django REST Framework backend for the Orphan Management System.

## Features

- User authentication with JWT
- Orphan data management
- Form submissions handling
- PDF report generation
- Excel export functionality
- Image upload to AWS S3
- RESTful API endpoints

## Tech Stack

- Django 5.0
- Django REST Framework
- PostgreSQL / SQLite
- JWT Authentication
- AWS S3 Storage
- Python 3.11+

## Setup

### Development Environment

1. Create virtual environment:
```bash
python -m virtualenv venv
source venv/bin/activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Configure environment:
```bash
cp env.development.example .env
```

4. Run migrations:
```bash
python manage.py migrate
```

5. Create superuser:
```bash
python manage.py createsuperuser
```

6. Run development server:
```bash
python manage.py runserver
```

### Production Environment

1. Install production dependencies:
```bash
pip install -r requirements-production.txt
```

2. Configure environment:
```bash
cp env.production.example .env
```

3. Follow production setup guide in `DEPLOYMENT.md`

## API Documentation

### Authentication
- POST `/api/login/` - User login
- POST `/api/logout/` - User logout
- POST `/api/token/refresh/` - Refresh JWT token

### Orphans
- GET `/api/orphans/` - List all orphans
- POST `/api/orphans/` - Create new orphan
- GET `/api/orphans/{id}/` - Get orphan details
- PUT `/api/orphans/{id}/` - Update orphan
- DELETE `/api/orphans/{id}/` - Delete orphan
- GET `/api/orphans/export/` - Export to Excel

### Forms
- GET `/api/forms/` - List all forms
- POST `/api/forms/` - Create new form
- GET `/api/forms/{id}/` - Get form details

### Users
- GET `/api/users/` - List users
- POST `/api/users/` - Create user

## Environment Variables

See `env.example` for required environment variables.

## License

Copyright © 2025. All rights reserved.
