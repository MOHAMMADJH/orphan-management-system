#!/bin/bash

echo "🚀 Setting up Production Environment..."

# Copy production env file
if [ ! -f .env ]; then
    echo "📝 Creating .env file for production..."
    cp env.production.example .env
    echo "✅ .env file created"
    echo "⚠️  IMPORTANT: Please update .env with your actual credentials!"
else
    echo "⚠️  .env file already exists. Skipping..."
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    virtualenv venv
    echo "✅ Virtual environment created"
fi

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Install dependencies (including PostgreSQL)
echo "📥 Installing dependencies..."
pip install -r requirements.txt -r requirements-production.txt

# Run migrations
echo "🗄️  Running migrations..."
python manage.py makemigrations
python manage.py migrate

# Collect static files
echo "📦 Collecting static files..."
python manage.py collectstatic --noinput

echo ""
echo "✅ Production environment setup complete!"
echo ""
echo "📋 Next steps:"
echo "   1. Update .env file with your actual credentials"
echo "   2. Create a superuser: python manage.py createsuperuser"
echo "   3. Run the production server: gunicorn orphan_management.wsgi:application"
echo ""
echo "💡 Note: Using PostgreSQL database and Cloudflare R2 storage"
echo ""

