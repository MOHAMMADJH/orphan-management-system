#!/bin/bash

echo "🚀 Setting up Development Environment..."

# Copy development env file
if [ ! -f .env ]; then
    echo "📝 Creating .env file for development..."
    cp env.development.example .env
    echo "✅ .env file created"
else
    echo "⚠️  .env file already exists. Skipping..."
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    virtualenv venv
    echo "✅ Virtual environment created"
fi

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Install dependencies (development only, no PostgreSQL)
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Create media directory if it doesn't exist
if [ ! -d "media" ]; then
    echo "📁 Creating media directory..."
    mkdir -p media
    echo "✅ Media directory created"
fi

# Run migrations
echo "🗄️  Running migrations..."
python manage.py makemigrations
python manage.py migrate

echo ""
echo "✅ Development environment setup complete!"
echo ""
echo "📋 Next steps:"
echo "   1. Create a superuser: python manage.py createsuperuser"
echo "   2. Run the development server: python manage.py runserver"
echo ""
echo "💡 Note: Using SQLite database (db.sqlite3) and local media storage (media/)"
echo ""

