# تحديث CORS للسماح بـ Netlify

## متى تحتاج لهذا؟

بعد نشر Frontend على Netlify، ستحصل على رابط مثل:
`https://your-site-name.netlify.app`

يجب إضافة هذا الرابط إلى إعدادات CORS في Backend للسماح بالاتصال.

## الخطوات

### 1. افتح ملف الإعدادات

```bash
cd /home/mohjas/CascadeProjects/AboNaheb/backend
```

افتح ملف: `orphan_management/settings.py`

### 2. ابحث عن CORS_ALLOWED_ORIGINS

ستجد شيء مثل هذا (حول السطر 169):

```python
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "https://205ef11b4d04.ngrok-free.app",
]
```

### 3. أضف رابط Netlify

```python
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "https://205ef11b4d04.ngrok-free.app",
    "https://your-site-name.netlify.app",  # أضف رابطك هنا
]
```

⚠️ **مهم**: 
- لا تضع `/` في نهاية الرابط
- تأكد من استخدام `https://` وليس `http://`
- استبدل `your-site-name` بالاسم الفعلي لموقعك

### 4. احفظ التغييرات

```bash
# إذا كان Backend محلي
python manage.py runserver

# إذا كان Backend على خادم
# أعد رفع Backend أو أعد تشغيله
```

## مثال كامل

إذا كان رابط Netlify الخاص بك: `https://orphans-zeitoun.netlify.app`

```python
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "https://orphans-zeitoun.netlify.app",
]
```

## للإنتاج (Production)

إذا كنت تستخدم متغيرات البيئة، يمكنك إضافة:

في `.env`:
```
NETLIFY_URL=https://your-site.netlify.app
```

في `settings.py`:
```python
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    config('NETLIFY_URL', default=''),
]
```

## التحقق

بعد التحديث:
1. أعد تشغيل Backend
2. افتح موقع Netlify
3. افتح Developer Tools (F12) → Console
4. حاول تسجيل الدخول
5. إذا نجح، إذاً CORS يعمل بشكل صحيح ✅

## إذا استمرت المشكلة

تحقق من:
- الرابط مكتوب بشكل صحيح (https وليس http)
- لا يوجد `/` في نهاية الرابط
- Backend تم إعادة تشغيله بعد التغيير
- Console في المتصفح يظهر رسالة CORS محددة

